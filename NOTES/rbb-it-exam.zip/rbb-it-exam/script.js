/**
 * RBB Level 5 Senior Assistant IT — Exam Preparation Platform
 * Core application logic (quiz engine, storage, analytics, UI)
 */

const STORAGE_KEY = 'rbb_it_exam_v1';

let questions = [];
let topicsData = null;
let state = {
  view: 'dashboard',
  quiz: null,          // current quiz state
  progress: null,      // loaded from localStorage
  settings: { sound: true, timer: true }
};

// ---------- Storage ----------
function loadProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      state.progress = JSON.parse(raw);
    } else {
      state.progress = {
        history: [],
        bookmarks: [],
        topicStats: {},      // topicId -> { attempted, correct, lastScore, ... }
        questionStats: {},   // qId -> { correct, incorrect, last }
        weakConcepts: [],
        settings: { sound: true, timer: true }
      };
    }
    state.settings = { ...state.settings, ...state.progress.settings };
  } catch (e) {
    console.warn('Failed to load progress', e);
    state.progress = { history: [], bookmarks: [], topicStats: {}, questionStats: {}, weakConcepts: [], settings: {} };
  }
}

function saveProgress() {
  try {
    state.progress.settings = state.settings;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.progress));
  } catch (e) {
    console.warn('Failed to save progress', e);
  }
}

// ---------- Data loading ----------
async function loadData() {
  const [qRes, tRes] = await Promise.all([
    fetch('questions.json'),
    fetch('topics.json')
  ]);
  questions = await qRes.json();
  topicsData = await tRes.json();
  document.getElementById('stat-total-q').textContent = questions.length;
}

// ---------- Navigation ----------
function showView(name) {
  document.querySelectorAll('.view').forEach(v => {
    v.classList.remove('active');
    v.hidden = true;
  });
  const el = document.getElementById(`view-${name}`);
  if (el) {
    el.classList.add('active');
    el.hidden = false;
  }
  document.querySelectorAll('.nav-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.view === name);
  });
  state.view = name;

  if (name === 'dashboard') renderDashboard();
  if (name === 'topics') renderTopics();
  if (name === 'quiz-setup') populateSetupForm();
  if (name === 'weak') renderWeakAreas();
  if (name === 'bookmarks') renderBookmarks();
  if (name === 'history') renderHistory();
  if (name === 'ai') checkWebGPU();
  if (name === 'settings') {
    document.getElementById('setting-sound').checked = state.settings.sound;
    document.getElementById('setting-timer').checked = state.settings.timer;
  }
}

// ---------- Dashboard ----------
function renderDashboard() {
  const p = state.progress;
  let totalAttempted = 0, totalCorrect = 0;
  Object.values(p.questionStats || {}).forEach(s => {
    totalAttempted += (s.correct || 0) + (s.incorrect || 0);
    totalCorrect += (s.correct || 0);
  });
  document.getElementById('stat-attempted').textContent = totalAttempted;
  document.getElementById('stat-accuracy').textContent =
    totalAttempted ? Math.round((totalCorrect / totalAttempted) * 100) + '%' : '—';

  // Mastery overview (simple)
  const masteryEl = document.getElementById('mastery-overview');
  if (!topicsData) return;
  let mastered = 0;
  const cards = [];
  topicsData.units.forEach(u => {
    u.topics.forEach(t => {
      const key = `${u.id}-${t.id}`;
      const st = p.topicStats[key] || { attempted: 0, correct: 0 };
      const acc = st.attempted ? st.correct / st.attempted : 0;
      let level = 'not-started';
      if (st.attempted >= 5 && acc >= 0.85) { level = 'mastered'; mastered++; }
      else if (st.attempted >= 3 && acc >= 0.7) level = 'strong';
      else if (st.attempted >= 2 && acc >= 0.5) level = 'developing';
      else if (st.attempted > 0) level = 'learning';
      cards.push(`<div class="mastery-item"><strong>${t.name}</strong><br><span class="mastery-badge ${level}">${level.replace('-', ' ')}</span></div>`);
    });
  });
  document.getElementById('stat-mastered').textContent = mastered;
  masteryEl.innerHTML = cards.slice(0, 12).join('') || '<p class="muted">Start practicing to see mastery.</p>';

  // Recent
  const recent = (p.history || []).slice(-5).reverse();
  const recentEl = document.getElementById('recent-activity');
  if (!recent.length) {
    recentEl.innerHTML = '<p class="muted">No quizzes yet. Start practicing!</p>';
  } else {
    recentEl.innerHTML = recent.map(h =>
      `<div style="padding:0.4rem 0;border-bottom:1px solid #f0f2f5;font-size:0.9rem">
        ${h.mode || 'Quiz'} · ${h.score}% · ${h.date || ''}
      </div>`
    ).join('');
  }
}

// ---------- Topics view ----------
function renderTopics() {
  const container = document.getElementById('topics-container');
  if (!topicsData) return;
  container.innerHTML = topicsData.units.map(u => {
    const topicsHtml = u.topics.map(t => {
      const key = `${u.id}-${t.id}`;
      const st = state.progress.topicStats[key] || { attempted: 0, correct: 0 };
      const acc = st.attempted ? Math.round((st.correct / st.attempted) * 100) : 0;
      let level = 'not-started';
      if (st.attempted >= 5 && acc >= 85) level = 'mastered';
      else if (st.attempted >= 3 && acc >= 70) level = 'strong';
      else if (st.attempted >= 2 && acc >= 50) level = 'developing';
      else if (st.attempted > 0) level = 'learning';
      const count = questions.filter(q => q.unit === u.id && q.topic === t.name).length;
      return `<div class="topic-row">
        <div class="topic-info">
          <div class="topic-name">${t.name}</div>
          <div class="topic-meta">${count} questions · Attempted ${st.attempted} · Accuracy ${acc}%</div>
        </div>
        <span class="mastery-badge ${level}">${level.replace('-', ' ')}</span>
        <button class="btn btn-primary btn-sm" data-start-topic="${u.id}|${t.name}">Practice</button>
      </div>`;
    }).join('');
    return `<div class="unit-card open" data-unit="${u.id}">
      <div class="unit-header">
        <h3>Unit ${u.id} — ${u.name} <span class="badge badge-outline">Section ${u.section}</span></h3>
      </div>
      <div class="unit-body">${topicsHtml}</div>
    </div>`;
  }).join('');

  container.querySelectorAll('[data-start-topic]').forEach(btn => {
    btn.addEventListener('click', () => {
      const [unit, topic] = btn.dataset.startTopic.split('|');
      startQuiz({ unit: Number(unit), topic, count: 10, mode: 'practice', difficulty: 'all' });
    });
  });
}

// ---------- Setup form ----------
function populateSetupForm() {
  const unitSel = document.getElementById('setup-unit');
  const topicSel = document.getElementById('setup-topic');
  unitSel.innerHTML = '<option value="all">All Units</option>' +
    topicsData.units.map(u => `<option value="${u.id}">Unit ${u.id} — ${u.name}</option>`).join('');

  function updateTopics() {
    const uid = unitSel.value;
    let opts = '<option value="all">All Topics</option>';
    topicsData.units.forEach(u => {
      if (uid !== 'all' && String(u.id) !== uid) return;
      u.topics.forEach(t => {
        opts += `<option value="${t.name}">${t.name}</option>`;
      });
    });
    topicSel.innerHTML = opts;
  }
  unitSel.onchange = updateTopics;
  updateTopics();
}

// ---------- Quiz engine ----------
function filterQuestions({ unit, topic, difficulty, count }) {
  let pool = [...questions];
  if (unit && unit !== 'all') pool = pool.filter(q => q.unit === Number(unit));
  if (topic && topic !== 'all') pool = pool.filter(q => q.topic === topic);
  if (difficulty && difficulty !== 'all') pool = pool.filter(q => q.difficulty === difficulty);
  // Shuffle
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, Math.min(count || 10, pool.length));
}

function startQuiz(opts) {
  const selected = filterQuestions(opts);
  if (!selected.length) {
    alert('No questions match the selected filters. Try different options.');
    return;
  }
  state.quiz = {
    questions: selected,
    answers: {},          // index -> selected option index
    marked: new Set(),
    current: 0,
    mode: opts.mode || 'practice',
    startTime: Date.now(),
    duration: opts.duration || selected.length * 60, // seconds
    timerId: null,
    finished: false
  };
  showView('quiz');
  renderQuestion();
  startTimer();
}

function renderQuestion() {
  const qz = state.quiz;
  if (!qz || qz.finished) return;
  const q = qz.questions[qz.current];
  const total = qz.questions.length;
  document.getElementById('quiz-progress').textContent = `Question ${qz.current + 1} / ${total}`;
  document.getElementById('q-difficulty').textContent = q.difficulty;
  document.getElementById('q-difficulty').className = `badge ${q.difficulty.toLowerCase().replace(' ', '-')}`;
  document.getElementById('q-topic').textContent = q.topic;
  document.getElementById('q-text').textContent = q.question;

  const optsEl = document.getElementById('q-options');
  const letters = ['A', 'B', 'C', 'D'];
  const answered = qz.answers[qz.current];
  const showFeedback = qz.mode === 'practice' && answered !== undefined;

  optsEl.innerHTML = q.options.map((opt, i) => {
    let cls = 'option';
    if (answered === i) cls += ' selected';
    if (showFeedback) {
      if (i === q.correctAnswer) cls += ' correct';
      else if (answered === i) cls += ' incorrect';
    }
    return `<button type="button" class="${cls}" data-opt="${i}" ${showFeedback ? 'disabled' : ''}>
      <span class="option-letter">${letters[i]}</span>
      <span>${opt}</span>
    </button>`;
  }).join('');

  optsEl.querySelectorAll('.option').forEach(btn => {
    btn.addEventListener('click', () => selectAnswer(Number(btn.dataset.opt)));
  });

  const fb = document.getElementById('q-feedback');
  if (showFeedback) {
    const correct = answered === q.correctAnswer;
    fb.hidden = false;
    fb.className = `feedback ${correct ? 'correct' : 'incorrect'}`;
    fb.innerHTML = `
      <h4>${correct ? '✓ Correct' : '✗ Incorrect'}</h4>
      <p><strong>Explanation:</strong> ${q.explanation}</p>
      <p><strong>Simple explanation:</strong> ${q.laymanExplanation || ''}</p>
      ${q.example ? `<p><strong>Example:</strong> ${q.example}</p>` : ''}
      ${q.memoryTrick ? `<p class="memory">💡 ${q.memoryTrick}</p>` : ''}
    `;
    if (correct && state.settings.sound) playSuccessSound();
  } else {
    fb.hidden = true;
  }

  document.getElementById('btn-prev').disabled = qz.current === 0;
  const isLast = qz.current === total - 1;
  document.getElementById('btn-next').hidden = isLast && qz.mode === 'exam';
  document.getElementById('btn-submit').hidden = !(isLast || qz.mode === 'exam');
  if (isLast) document.getElementById('btn-submit').hidden = false;

  renderNavigator();
}

function selectAnswer(optIdx) {
  const qz = state.quiz;
  if (qz.finished) return;
  if (qz.mode === 'practice' && qz.answers[qz.current] !== undefined) return;
  qz.answers[qz.current] = optIdx;
  renderQuestion();
}

function renderNavigator() {
  const qz = state.quiz;
  const nav = document.getElementById('question-navigator');
  nav.innerHTML = qz.questions.map((_, i) => {
    let cls = 'q-nav-btn';
    if (i === qz.current) cls += ' current';
    if (qz.answers[i] !== undefined) cls += ' answered';
    if (qz.marked.has(i)) cls += ' marked';
    return `<button type="button" class="${cls}" data-goto="${i}">${i + 1}</button>`;
  }).join('');
  nav.querySelectorAll('[data-goto]').forEach(b => {
    b.addEventListener('click', () => {
      qz.current = Number(b.dataset.goto);
      renderQuestion();
    });
  });
}

function startTimer() {
  const qz = state.quiz;
  if (!state.settings.timer) {
    document.getElementById('quiz-timer').style.display = 'none';
    return;
  }
  document.getElementById('quiz-timer').style.display = '';
  function tick() {
    if (!qz || qz.finished) return;
    const elapsed = Math.floor((Date.now() - qz.startTime) / 1000);
    const remaining = Math.max(0, qz.duration - elapsed);
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    const el = document.getElementById('quiz-timer');
    el.textContent = `${m}:${String(s).padStart(2, '0')}`;
    el.classList.toggle('warning', remaining < 60);
    if (remaining <= 0) {
      submitQuiz();
      return;
    }
    qz.timerId = setTimeout(tick, 1000);
  }
  tick();
}

function submitQuiz() {
  const qz = state.quiz;
  if (!qz || qz.finished) return;
  qz.finished = true;
  if (qz.timerId) clearTimeout(qz.timerId);

  let correct = 0, incorrect = 0, unanswered = 0;
  qz.questions.forEach((q, i) => {
    const a = qz.answers[i];
    if (a === undefined) unanswered++;
    else if (a === q.correctAnswer) correct++;
    else incorrect++;

    // Update question stats
    const qs = state.progress.questionStats[q.id] || { correct: 0, incorrect: 0 };
    if (a === q.correctAnswer) qs.correct++;
    else if (a !== undefined) qs.incorrect++;
    state.progress.questionStats[q.id] = qs;

    // Topic stats
    const key = `${q.unit}-${q.topic}`;
    const ts = state.progress.topicStats[key] || { attempted: 0, correct: 0 };
    ts.attempted++;
    if (a === q.correctAnswer) ts.correct++;
    state.progress.topicStats[key] = ts;
  });

  const total = qz.questions.length;
  const score = Math.round((correct / total) * 100);
  const timeUsed = Math.floor((Date.now() - qz.startTime) / 1000);

  state.progress.history.push({
    date: new Date().toLocaleString(),
    mode: qz.mode,
    total,
    correct,
    incorrect,
    unanswered,
    score,
    timeUsed
  });
  saveProgress();

  // Show results
  document.getElementById('result-score').textContent = score + '%';
  document.documentElement.style.setProperty('--score-pct', score + '%');
  document.getElementById('result-correct').textContent = correct;
  document.getElementById('result-incorrect').textContent = incorrect;
  document.getElementById('result-unanswered').textContent = unanswered;
  document.getElementById('result-time').textContent = `${Math.floor(timeUsed / 60)}m ${timeUsed % 60}s`;

  const breakdown = document.getElementById('result-breakdown');
  breakdown.innerHTML = '<h3>Question Review</h3>' + qz.questions.map((q, i) => {
    const a = qz.answers[i];
    const ok = a === q.correctAnswer;
    const status = a === undefined ? 'Unanswered' : (ok ? 'Correct' : 'Incorrect');
    return `<div style="padding:0.5rem 0;border-bottom:1px solid #f0f2f5;font-size:0.9rem">
      <strong>Q${i + 1}.</strong> ${q.question.substring(0, 80)}… — <span style="color:${ok ? 'var(--success)' : (a === undefined ? 'var(--text-muted)' : 'var(--danger)')}">${status}</span>
    </div>`;
  }).join('');

  showView('results');
  document.getElementById('view-results').hidden = false;
  document.getElementById('view-results').classList.add('active');
}

function playSuccessSound() {
  // Simple Web Audio success tone
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    gain.gain.value = 0.08;
    osc.start();
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
    osc.stop(ctx.currentTime + 0.3);
  } catch (_) {}
}

// ---------- Weak / Bookmarks / History ----------
function renderWeakAreas() {
  const el = document.getElementById('weak-list');
  const stats = state.progress.topicStats || {};
  const weak = Object.entries(stats)
    .filter(([, s]) => s.attempted >= 2 && (s.correct / s.attempted) < 0.6)
    .sort((a, b) => (a[1].correct / a[1].attempted) - (b[1].correct / b[1].attempted));
  if (!weak.length) {
    el.innerHTML = '<p class="muted">No weak areas identified yet (need at least 2 attempts with &lt;60% accuracy).</p>';
    return;
  }
  el.innerHTML = weak.map(([key, s]) => {
    const acc = Math.round((s.correct / s.attempted) * 100);
    return `<div class="topic-row">
      <div class="topic-info"><div class="topic-name">${key}</div>
      <div class="topic-meta">${s.attempted} attempted · ${acc}% accuracy</div></div>
      <button class="btn btn-primary" data-weak="${key}">Practice</button>
    </div>`;
  }).join('');
}

function renderBookmarks() {
  const el = document.getElementById('bookmark-list');
  const bms = state.progress.bookmarks || [];
  if (!bms.length) {
    el.innerHTML = '<p class="muted">No bookmarked questions yet. Use the Mark button during a quiz.</p>';
    return;
  }
  el.innerHTML = bms.map(id => {
    const q = questions.find(x => x.id === id);
    if (!q) return '';
    return `<div class="topic-row"><div class="topic-info"><div class="topic-name">${q.question.substring(0, 100)}…</div>
      <div class="topic-meta">${q.topic} · ${q.difficulty}</div></div></div>`;
  }).join('');
}

function renderHistory() {
  const el = document.getElementById('history-list');
  const hist = (state.progress.history || []).slice().reverse();
  if (!hist.length) {
    el.innerHTML = '<p class="muted">No history yet.</p>';
    return;
  }
  el.innerHTML = hist.map(h =>
    `<div class="topic-row"><div class="topic-info">
      <div class="topic-name">${h.mode || 'Quiz'} — ${h.score}%</div>
      <div class="topic-meta">${h.correct}/${h.total} correct · ${h.date}</div>
    </div></div>`
  ).join('');
}

// ---------- WebGPU / AI stub ----------
function checkWebGPU() {
  const el = document.getElementById('webgpu-status');
  if (navigator.gpu) {
    el.innerHTML = '<strong>WebGPU available.</strong> WebLLM integration can be enabled for local AI question generation. Curated bank remains primary.';
    document.getElementById('btn-ai-generate').disabled = true; // full integration requires model + pipeline
  } else {
    el.innerHTML = '<strong>WebGPU not available</strong> in this browser. Curated question bank works normally. Try Chrome/Edge for WebLLM support.';
  }
}

// ---------- Event wiring ----------
function wireEvents() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => showView(btn.dataset.view));
  });

  document.getElementById('menuToggle')?.addEventListener('click', () => {
    const nav = document.querySelector('.main-nav');
    nav.classList.toggle('open');
  });

  document.getElementById('quiz-setup-form')?.addEventListener('submit', e => {
    e.preventDefault();
    startQuiz({
      unit: document.getElementById('setup-unit').value,
      topic: document.getElementById('setup-topic').value,
      difficulty: document.getElementById('setup-difficulty').value,
      count: Number(document.getElementById('setup-count').value),
      mode: document.getElementById('setup-mode').value
    });
  });

  document.getElementById('btn-prev')?.addEventListener('click', () => {
    if (state.quiz.current > 0) {
      state.quiz.current--;
      renderQuestion();
    }
  });
  document.getElementById('btn-next')?.addEventListener('click', () => {
    if (state.quiz.current < state.quiz.questions.length - 1) {
      state.quiz.current++;
      renderQuestion();
    }
  });
  document.getElementById('btn-skip')?.addEventListener('click', () => {
    if (state.quiz.current < state.quiz.questions.length - 1) {
      state.quiz.current++;
      renderQuestion();
    }
  });
  document.getElementById('btn-mark')?.addEventListener('click', () => {
    const i = state.quiz.current;
    if (state.quiz.marked.has(i)) state.quiz.marked.delete(i);
    else state.quiz.marked.add(i);
    // also bookmark the question
    const qid = state.quiz.questions[i].id;
    if (!state.progress.bookmarks.includes(qid)) {
      state.progress.bookmarks.push(qid);
      saveProgress();
    }
    renderNavigator();
  });
  document.getElementById('btn-submit')?.addEventListener('click', submitQuiz);

  document.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', () => {
      const a = btn.dataset.action;
      if (a === 'start-random') startQuiz({ count: 20, mode: 'practice' });
      if (a === 'start-topic') showView('quiz-setup');
      if (a === 'start-mock' || a === 'mock-50') startQuiz({ count: 50, mode: 'exam', duration: 3600 });
      if (a === 'mock-30') startQuiz({ count: 30, mode: 'exam', duration: 2400 });
      if (a === 'mock-20') startQuiz({ count: 20, mode: 'exam', duration: 1500 });
      if (a === 'start-weak') showView('weak');
      if (a === 'back-dashboard') showView('dashboard');
      if (a === 'retry-quiz' && state.quiz) {
        startQuiz({
          count: state.quiz.questions.length,
          mode: state.quiz.mode,
          // re-filter roughly
        });
      }
      if (a === 'review-mistakes') {
        // simple: re-show results breakdown already visible
        alert('Scroll the question review below to see mistakes. Full review mode coming in next iteration.');
      }
    });
  });

  document.getElementById('setting-sound')?.addEventListener('change', e => {
    state.settings.sound = e.target.checked;
    saveProgress();
  });
  document.getElementById('setting-timer')?.addEventListener('change', e => {
    state.settings.timer = e.target.checked;
    saveProgress();
  });
  document.getElementById('btn-reset-progress')?.addEventListener('click', () => {
    if (confirm('Reset all progress, history and bookmarks? This cannot be undone.')) {
      localStorage.removeItem(STORAGE_KEY);
      loadProgress();
      renderDashboard();
      alert('Progress reset.');
    }
  });
}

// ---------- Init ----------
async function init() {
  loadProgress();
  await loadData();
  wireEvents();
  showView('dashboard');
}

init().catch(err => {
  console.error(err);
  document.body.insertAdjacentHTML('afterbegin',
    `<div style="background:#fee;padding:1rem;text-align:center">Failed to load question bank. Check that questions.json is present.</div>`);
});
