# RBB Level 5 Senior Assistant — Information Technology
## Interactive Exam Preparation Platform

Professional MCQ practice system for Rastriya Banijya Bank Limited (RBB) Level 5 Senior Assistant (IT) examination.

### Features
- **Curated Question Bank**: High-quality MCQs aligned to official syllabus (Paper II — Information Technology & Management)
- **Topic-wise & Subtopic-wise Practice**
- **Practice Mode** (immediate feedback) & **Exam Mode** (submit at end)
- **Mock Tests** with timed full-length exams
- **Weak-Area Detection** & Personalized Revision
- **Progress Tracking** via localStorage / IndexedDB
- **Analytics Dashboard** (accuracy, mastery, time analysis)
- **Bookmark System**
- **Quiz History**
- **WebLLM-ready Architecture** (local AI generation with graceful fallback)
- **Responsive Design** (Desktop / Tablet / Mobile)
- **Accessibility** support

### Syllabus Coverage (Paper II — 100 Marks)
**Section A (50 Marks)**
- Unit 1: Introduction of Computer
- Unit 2: Computer Architecture
- Unit 3: Communication and Computer Network Technologies

**Section B (50 Marks)**
- Unit 4: Operating System and Information Systems
- Unit 5: DBMS, Data Mining/Warehousing and Web Technology
- Unit 6: Cybersecurity and IT Policies

### Project Structure
```
/
├── index.html
├── style.css
├── script.js
├── questions.json          # Validated MCQ bank
├── topics.json             # Topic / subtopic metadata
├── assets/
│   └── success.mp3         # Optional success sound
├── js/
│   ├── quiz-engine.js
│   ├── timer.js
│   ├── scoring.js
│   ├── analytics.js
│   ├── storage.js
│   ├── question-validator.js
│   ├── duplicate-detector.js
│   └── webllm-engine.js
├── ai/
│   ├── prompts.js
│   ├── schemas.js
│   └── validators.js
└── README.md
```

### How to Run
Simply open `index.html` in a modern browser (Chrome/Edge recommended for WebGPU/WebLLM).  
No backend required for core functionality.

### Question Bank Status
See `questions.json` and the validation report generated at build time.  
Never claim 1000+ until the validated unique count reaches that number.

### Important Notes
- Policy questions (ICT Policy 2072, NRB IT Guidelines 2012, Cyber Resilience Guidelines 2023) are based on publicly available authoritative summaries. Always cross-check official PDFs for the latest version.
- AI-generated questions (when WebLLM is enabled) are clearly labelled and must pass validation.
- This is an educational tool, not an official RBB/Loksewa product.

### Development Roadmap
1. Core quiz engine + localStorage ✅
2. Topic filtering + mastery tracking
3. Analytics dashboard
4. Expand question bank in validated batches toward 1000+
5. WebLLM integration (model loading + JSON validation pipeline)
6. Full accessibility audit & mobile polish

Built for serious exam preparation. Accuracy and syllabus alignment are the top priorities.
