let DATA={questions:[]}, quiz=[], qi=0, score=0, answered=false;
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
async function loadData(){
 try{const r=await fetch('mcq_dataset_1126.json'); DATA=await r.json();}
 catch(e){console.error(e); return;}
 $('#totalStat').textContent=DATA.questions.length; populateUnits(); renderBank();
}
function populateUnits(){
 const units=[...new Set(DATA.questions.map(q=>q.unit))];
 $('#unitFilter').innerHTML='<option value="all">All Units</option>'+units.map(u=>`<option value="${u}">${u}</option>`).join('');
}
function filtered(){
 const sec=$('#sectionFilter').value, unit=$('#unitFilter').value, diff=$('#difficultyFilter').value;
 return DATA.questions.filter(q=>(sec==='all'||q.section===sec)&&(unit==='all'||q.unit===unit)&&(diff==='all'||q.difficulty===diff));
}
function startQuiz(){
 let pool=filtered(); if(!pool.length)return;
 const n=+$('#countFilter').value; pool=[...pool].sort(()=>Math.random()-.5).slice(0,n);
 quiz=pool;qi=0;score=0;answered=false;renderQuestion();
}
function renderQuestion(){
 const q=quiz[qi]; answered=false;
 $('#quizArea').innerHTML=`<div class="qmeta">Question ${qi+1} of ${quiz.length} • ${q.unit} • ${q.difficulty}</div>
 <div class="progress"><span style="width:${(qi/quiz.length)*100}%"></span></div>
 <div class="question">${esc(q.question)}</div>
 <div class="options">${q.options.map((o,i)=>`<button class="option" data-i="${i}"><b>${String.fromCharCode(65+i)}.</b> ${esc(o)}</button>`).join('')}</div>
 <div id="explain"></div><div class="quiz-nav"><button class="header-actions button" id="prev" ${qi===0?'disabled':''}>Previous</button><button class="primary" id="next">${qi===quiz.length-1?'Finish':'Next'}</button></div>`;
 $$('.option').forEach(b=>b.onclick=()=>choose(+b.dataset.i));
 $('#prev').onclick=()=>{if(qi>0){qi--;renderQuestion()}};
 $('#next').onclick=()=>{if(!answered)return alert('Select an answer first.'); if(qi<quiz.length-1){qi++;renderQuestion()}else finishQuiz()};
}
function choose(i){
 if(answered)return; answered=true; const q=quiz[qi], opts=$$('.option');
 opts.forEach((b,k)=>{if(k===q.answer)b.classList.add('correct'); if(k===i&&i!==q.answer)b.classList.add('wrong')});
 if(i===q.answer)score++;
 $('#explain').innerHTML=`<div class="explanation"><b>${i===q.answer?'Correct':'Answer: '+String.fromCharCode(65+q.answer)}</b><br>${esc(q.explanation)}</div>`;
}
function finishQuiz(){ $('#quizArea').innerHTML=`<div class="empty"><h3>Quiz complete</h3><p>Your score: <b>${score}/${quiz.length}</b> (${Math.round(score/quiz.length*100)}%)</p><button class="primary" onclick="startQuiz()">Try Again</button></div>`;}
function renderBank(){
 let list=DATA.questions;
 const s=$('#search').value.toLowerCase(), sec=$('#bankSection').value, d=$('#bankDifficulty').value;
 list=list.filter(q=>(!s||(q.question+' '+q.topic+' '+q.unit).toLowerCase().includes(s))&&(sec==='all'||q.section===sec)&&(d==='all'||q.difficulty===d)).slice(0,80);
 $('#bankList').innerHTML=list.map(q=>`<article class="qitem"><div class="qtop"><span class="tag">${q.id}</span><span class="tag">${q.topic}</span></div><div class="qtext">${esc(q.question)}</div><div class="answers">${q.options.map((o,i)=>`<div class="answer ${i===q.answer?'correct':''}">${String.fromCharCode(65+i)}. ${esc(o)}</div>`).join('')}</div></article>`).join('')||'<div class="card">No matching questions.</div>';
}
function extractNotes(){
 const text=$('#notes').value.trim(); if(!text)return alert('Paste some notes first.');
 const sentences=text.split(/(?<=[.!?])\s+|\n+/).map(s=>s.trim()).filter(s=>s.length>25).slice(0,+$('#extractCount').value);
 const out=sentences.map((s,i)=>makeExtracted(s,i+1));
 $('#extracted').innerHTML=out.map(x=>`<div class="extracted-item"><b>${x.question}</b><div class="answers">${x.options.map((o,k)=>`<div class="answer ${k===x.answer?'correct':''}">${String.fromCharCode(65+k)}. ${esc(o)}</div>`).join('')}</div></div>`).join('')||'<p>No sufficiently complete statements found.</p>';
}
function makeExtracted(s,i){
 const words=s.replace(/[^\w\s-]/g,'').split(/\s+/).filter(w=>w.length>3);
 const key=words.slice(-1)[0]||'concept'; const q=`According to the extracted note, which statement is correct?`;
 let opts=[s,'The note does not describe this concept.','The statement reverses the relationship described in the note.','The concept is unrelated to information technology.'];
 return {question:q,options:opts,answer:0};
}
function esc(x){return String(x).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
$$('.tab').forEach(t=>t.onclick=()=>{$$('.tab').forEach(x=>x.classList.remove('active'));$$('.panel').forEach(x=>x.classList.remove('active'));t.classList.add('active');$('#'+t.dataset.tab).classList.add('active')});
$('#startQuiz').onclick=startQuiz; $('#startQuiz2').onclick=startQuiz;
$('#search').oninput=renderBank; $('#bankSection').onchange=renderBank; $('#bankDifficulty').onchange=renderBank;
$('#shuffleBank').onclick=()=>{DATA.questions.sort(()=>Math.random()-.5);renderBank()};
$('#extractBtn').onclick=extractNotes;
$('#themeBtn').onclick=()=>document.body.classList.toggle('dark');
$('#jsonInput').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{DATA=JSON.parse(await f.text());$('#totalStat').textContent=DATA.questions.length;populateUnits();renderBank();alert('JSON imported successfully.')}catch(err){alert('Invalid JSON file.')}};
loadData();