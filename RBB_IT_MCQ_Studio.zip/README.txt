# RBB IT MCQ Studio
Open `index.html` in a modern browser. Keep `mcq_dataset_1126.json` in the same folder.
Features:
- 1126 JSON MCQs
- Section A/B and Unit filters
- Difficulty filters
- Random quiz mode and scoring
- Searchable question bank
- JSON import
- Note Extract feature: paste notes and generate editable practice MCQs locally
- Dark mode
- No server required
